import Footer from './components/Footer';
import Header from './components/Header';
import LoginPage from './pages/loginpage';
import RegisterPage from './pages/register';


function App() {
  return (
    <div>
      <Header />
      {/* <LoginPage /> */}
      <RegisterPage />
      <br></br>
      <Footer />
    </div>
  );
}

export default App;
