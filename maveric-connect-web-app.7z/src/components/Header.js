import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

class Header extends React.Component
{
render()
{
return (
<nav class="navbar navbar-expand-lg navbar-light bg-light">
<ul class="navbar-nav">
<li class="nav-item active">

<a class="nav-link" href="#"><img src="maveric-logo-updated.png" alt="Logo" /></a>
</li>

<li class="nav-item">
<a class="navbar-brand disabled" href="#"><b><h2>Maveric Connect</h2></b></a>
</li>
</ul>
</nav>

)
}
}
export default Header;