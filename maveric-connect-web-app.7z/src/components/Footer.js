
import React from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';

class Footer extends React.Component
{
render()
{
return (
<div class="jumbotron text-center" >
@Copyright, Maveric Systems Ltd 2022
    <img  class="logo" src="maveric-logo-updated.png" alt="Logo" />
</div>
)
}
}
export default Footer;