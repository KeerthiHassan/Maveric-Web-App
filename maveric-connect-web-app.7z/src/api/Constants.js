const Constants = {
    BASE_URL: '',
    IMAGE_URL: 'http://rjtmobile.com/grocery/images/'
}
export default Constants;