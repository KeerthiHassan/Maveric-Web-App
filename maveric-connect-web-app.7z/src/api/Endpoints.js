const Endpoints = {
    CATEGORY_URL: 'https://apolis-grocery.herokuapp.com/api/category"',
    SUBCATEGOY_URL: '',
    PRODUCT_BY_CAT_ID:'',
    LOGIN_URL:'',
    REGISTER_URL:''
}
export default Endpoints;